rm(list=ls())

library(tidyr)
library(stringr)
library(dplyr)
library(foreign)
library(lubridate)
library(chron)

getwd()
setwd("C:\\Users\\user\\Desktop\\masters for march\\interview questions\\Victor_Mandela_MLIS")


##################################
### load the participants data  ##
##################################

ids<-read.csv("p2_names.csv",stringsAsFactors = FALSE)
base_1<-read.csv("11.csv",stringsAsFactors = FALSE)
base_2<-read.csv("12.csv",stringsAsFactors = FALSE)
base_3<-read.csv("14.csv",stringsAsFactors = FALSE)

suma1<-summary(base_1)
suma2<-summary(base_2)
suma3<-summary(base_3)

#write.csv(suma1,"suma1.csv")
#write.csv(suma1,"suma2.csv")
#write.csv(suma1,"suma3.csv")

#############################
####  format TimeStamp  #####
#############################

date_time_1<-as.POSIXlt(mdy_hm(base_1$TimeStamp))
date_time_2<-as.POSIXlt(mdy_hm(base_2$TimeStamp))
date_time_3<-as.POSIXlt(mdy_hm(base_3$TimeStamp))




##################################
#### replace the time variable  ##
###  	 	and order it 	  	      ##
##################################

new_b1<-cbind(date_time_1,base_1)
  new_b1<-new_b1[,-6]
  new_b1=new_b1[order(date_time_1),]

new_b2<-cbind(date_time_2,base_2)
  new_b2<-new_b2[,-6]
  new_b2=new_b2[order(date_time_3),]

new_b3<-cbind(date_time_3,base_3)
 new_b3-new_b3[,-6]
  new_b3=new_b3[order(date_time_3),]


##############################################
### after formating the timestamp variable ###
####  	save in stata format   		####
##############################################


#write.dta(new_b1,"new base 1.dta")
#write.dta(new_b2,"new base 2.dta")
#write.dta(new_b3,"new base 3.dta")

##############################################
### 		duplicate data              ######
##############################################


dup_in_base_1<-new_b1[duplicated(new_b1$partid),]
dup_in_base_2<-new_b2[duplicated(new_b2$partid),]
dup_in_base_3<-new_b3[duplicated(new_b3$partid),]

#write.csv(dup_in_base_1,"dup in data one")
#write.csv(dup_in_base_1,"dup in data two")
#write.csv(dup_in_base_1,"dup in data three")

##############################################
### 	data with no duplicate IDs            ##
##############################################

new_b1<-new_b1[!duplicated(new_b1$partid),]
new_b2<-new_b2[!duplicated(new_b2$partid),]
new_b3<-new_b3[!duplicated(new_b3$partid),]

#write.csv(dup_in_baseb_1,"list of all ID without duplicates in data 1")
#write.csv(dup_in_baseb_1,"list of all ID without duplicates in data 2")
#write.csv(dup_in_baseb_1,"list of all ID without duplicates in data 3")



################################################
### 	merge all the data sets together on the ##
###			adm data			    ##
################################################

#join 11 and 12 - call it merged
merged = merge(new_b1,new_b2)

#join merged and 14 - call it merged 2
merged2 = merge(merged,new_b3)

#join merged 2 on adm data - call it merged_on_id
merged_on_id =merge(merged2,ids)

#write.csv(merged_on_id,"merged on the adm data.csv")
#write.dta(merged_on_id,"merged on the adm data.dta")



##############################################
### 			incomplete survey        ##
##############################################


# list rows of data that have missing values 

part_complete1<-new_b1[!complete.cases(new_b1),]
part_complete2<-new_b1[!complete.cases(new_b2),]
part_complete3<-new_b1[!complete.cases(new_b3),]

ids_part1<-part_complete1$partid
ids_part2<-part_complete2$partid
ids_part3<-part_complete3$partid

setequal(ids_part1,ids_part2)

write.csv(part_complete1,"ids that are partially complete.csv")
write.csv(ids_part,"ids part.csv")

###############################
## ids not yet surveyed   ####
##############################

ids_in1<-new_b1$partid
ids_in2<-new_b2$partid
ids_in3<-new_b3$partid

ids_on_roster<-ids$partid

a=setdiff(ids_on_roster,ids_in1)
b=setdiff(ids_on_roster,ids_in2)
c=setdiff(ids_on_roster,ids_in2)

#these are the ids not yet surveyed
#[5] 20413 20453 20470 20424

#extraneous observations 
d=setdiff(ids_in2,ids_on_roster)
e=setdiff(ids_in3,ids_on_roster)
f=setdiff(ids_in1,ids_on_roster)

#this is the only extraneous var
#[1]20305

################################################
###  in-sample observations that are complete ##
################################################

complete1<-new_b1[complete.cases(new_b1),]
complete2<-new_b1[complete.cases(new_b2),]
complete3<-new_b1[complete.cases(new_b3),]

da=setequal(complete1,complete2)
ea=setequal(complete3,complete1)

incomp<-new_b1[!complete.cases(new_b1),]
#all of records were dropped. 

#write.csv(a,"ids not yet surveyed.csv")
#write.csv(complete1,"in-sample observations that are complete.csv")

#####################################################
## creation of a categorical variable drinkalcohol ##
#####################################################


drinkalcohol<-new_b1$drinkbeerwinexamt
ifelse(drinkalcohol>0,"1","0")

